======================================================================
Arcanum Dialog Editor
======================================================================
http://www.labyrinth.net.au/~adsoft/arcanum
Grant Davies, October 2001.
<adsoft@labyrinth.net.au>

======================================================================
License
======================================================================
The Arcanum Dialog Editor is free for non-profit and non-commercial 
use.

======================================================================
Introduction
======================================================================

DialogEditor facilitates the editing of Arcanum dialog (*.dlg) files.
Dialog files describe the possibilities of a single conversation in
an Arcanum mod.

To read further about Arcanum dialog files, check the reference section.

DialogEditor provides additional benefits above and beyond editing
dialog files in a text editor:

- Hides the underlying file-format, meaning your dialog files are
much more likely to work since you dont have to grapple with learning
where to put which values.

- Organises the dialog into dialog pages, which are easier to edit
then a file of lines.

- Allows you to use labels for your dialogs.  In other words, you can
label a dialog page as, for example, "EntranceSpeech" and refer to it
by that name within the dialog editor.  Much easier than using numbers!
Especially when those numbers constantly change!

- Allows you to enter descriptions for any dialog line.  You can enter
a description for any NPC or PC dialog line.  For example, "This is
what the thug will say when the PC first sees him", or "This option 
is only available after the PC has completed the quest".

- Is much faster to edit!

Feedback is always welcome.  You can mail me at <adsoft@labyrinth.net.au>
with bugs/suggestions/comments/whatever.  If you have a technical
question about dialog in Arcanum, please check the documents in the 
References section before mailing me.

======================================================================
!!IMPORTANT!!
======================================================================

Please make sure you backup all dialog files before using this program.
As yet, DialogEditor has not been tested on a large scale.  As such, I
do not want to be responsible for someone losing hours of work on a 
dialog file!  In particular, the format of the dialog file may be
rearranged by the DialogEditor.

Another important issue to be aware of when using the DialogEditor is
that it WILL reorder lines in the dialog file.  Therefore, you will
probably need to re-enter any references to dialog lines from within
script files.  DialogEditor will, however, attempt to prevent the
line numbers from changing once they have been initially re-ordered.

If you are in any doubt about these issues, do not use this program.

======================================================================
Command Line
======================================================================

DialogEditor accepts one optional command-line parameter - the dialog 
file to open.

Usage: DialogEditor <FileName.dlg>

======================================================================
References/Further Reading
======================================================================

EditDocs.zip, Troika Games web site.
	- http://www.troikagames.com/downloads/editdocs.zip
	: GeneratedDialog.doc
		Description of engine-generated dialog options for PCs and NPCs.
	: EventScripts.doc
		Brief description of the dlg file format.

Mod building 102 - "The Dungeon Crawl Revisited"
	- http://rpgvault.ign.com/features/specials/arcanummod02.shtml
		Brief overview of dialog in general.

Dialog tutorial
	- http://www.angrynerds.com/beyond/index.html
		More in-depth description of dialog files.

======================================================================
Thankyou
======================================================================
Thank you to Troika Games, for making Arcanum, and while I'm at it,
for making Fallout, a great game which reminds me of one of my favourite
games of all time, Wasteland.

======================================================================
History
======================================================================

20-Oct-2001		Version 1.03
				Fixed bug with moving PC lines up/down not saving
				Fixed bug with PC lines male/female only being read as NPC lines

11-Oct-2001		Version 1.02
				Changed the line numbering system to begin at 1, 21, 41,
				etc. (make it easier to script, starting at 1).
				Fixed bugs with 5th and 6th segments in NPC lines

 7-Oct-2001		Version 1.01
				Added "New" (dialog file) support to the menu
				Fixed bug with Exit -> Save -> Cancel still exiting
				Resizable main dialog window
				App initialise with no argument defaults to new dialog file
				Fixed bug adding 1 to the start of some intelligence checks

 4-Oct-2001		Initial revision
